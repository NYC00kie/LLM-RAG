<?php
// English language strings for the chat plugin.

$string['pluginname'] = 'Global Chat Plugin';
$string['enablechat'] = 'Enable Chat';
$string['enablechat_desc'] = 'Enable or disable the global chat system.';
